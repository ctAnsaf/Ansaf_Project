export const environment = {
  production: true,
  apiUrl: 'https://testing.competitivecracker.com/api/v1/user/',
};
