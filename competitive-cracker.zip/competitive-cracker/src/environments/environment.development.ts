export const environment = {
  production: false,
  apiUrl: 'https://testing.competitivecracker.com/api/v1/user/',
};
